### Shaders

These are the default shaders used for rendering 2D and 3D diagrams in
OpenGL.
