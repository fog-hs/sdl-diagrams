Haskell Typography. Currently using freetype and harfbuzz for
rendering/shaping. This package is used for rendering text in
[diagrams-gl](https://github.com/cchalmers/diagrams-gl).

Still in early development.

