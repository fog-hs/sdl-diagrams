## diagrams-sdl

An SDL2 backend to the diagrams library. **Only works on my
own [`diagrams`](https://github.com/cchalmers/diagrams) fork.**

### 3D backend

Supports basic camera movements from mouse input and multitouch
gestures.

Rendering is done by
[`diagrams-gl`](https://github.com/cchalmers/diagrams-gl).

